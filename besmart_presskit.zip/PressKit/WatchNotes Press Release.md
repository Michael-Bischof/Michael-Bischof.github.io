# Be Smart - Privacy matters

Cologne, Germany — Feburary 23rd 2020 —  Michael Bischof today released "Be Smart - Privacy matters" for iOS. Be Smart lets the user discover all the information apps can access once installed and once given certain permissions.
It uses data on the users phone to emphasise the importance of privacy and to get the users attention regarding the importance of privacy.

It goes without saying, that when using Be Smart no data is being saved, stored, tracked or uploaded.

## Be Smart Features
- Explore the data apps can access on your phone without any permissions
- Discover what exactly is possible when giving an app certain permissions

## Pricing and Availability
Be Smart is available on the App Store for free. Be Smart requires iOS 12.0 or newer.

App Store Link: http://itunes.apple.com/app/id1498315494

### Additional Information
The press kit can be downloaded from here: https://michael-bischof.github.io/besmart_presskit.zip

### About Michael Bischof
Independent developer from Cologne, Germany.


### Press Contact
Michael Bischof<br>
Eifelplatz 19, D-50677 Cologne<br>
Email: besmartapp@icloud.com<br>
Twitter:  @michael_bischof


